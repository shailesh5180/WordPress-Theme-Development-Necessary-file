<?php 
function publish_post_tweet( $ID, $post ) {
    
	// Send tweet
	

}
add_action( 'publish_post', 'publish_post_tweet', 10, 2 );

?>