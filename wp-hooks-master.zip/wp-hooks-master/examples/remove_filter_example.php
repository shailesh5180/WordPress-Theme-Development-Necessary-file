<?php 
remove_filter( 'excerpt_length', 'my_custom_excerpt_length' );
?>