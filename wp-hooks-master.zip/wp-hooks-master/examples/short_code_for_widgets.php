<?php
 
add_filter( 'widget_text', 'do_shortcode' );

// http://code.tutsplus.com/tutorials/50-filters-of-wordpress-filters-21-30--cms-21298

?>