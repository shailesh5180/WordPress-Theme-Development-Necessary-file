<title><?php wp_title( '|', true, 'right' ); ?></title>

<?php wp_head(); ?>

<?php wp_footer(); ?>